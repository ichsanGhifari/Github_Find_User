package com.wak.submission2fundamental.data

object MainData {
    const val  gitToken = "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"
}