package com.wak.submission2fundamental.ui.settings

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.CompoundButton
import com.wak.submission2fundamental.broadcastreceiver.ReminderReceiver
import com.wak.submission2fundamental.R
import com.wak.submission2fundamental.databinding.ActivitySettingsBinding

class SettingsActivity : AppCompatActivity(), View.OnClickListener,
    CompoundButton.OnCheckedChangeListener {

    private lateinit var settingsBinding: ActivitySettingsBinding
    private lateinit var reminderReceiver: ReminderReceiver

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settingsBinding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(settingsBinding.root)
        settingsBinding.localizationSettings.setOnClickListener(this)
        settingsBinding.switchReminder.setOnCheckedChangeListener(this)
        reminderReceiver = ReminderReceiver()
        supportActionBar?.title = "Settings"
    }
    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
    override fun onClick(view: View?) {
        when (view?.id) {
            R.id.localization_settings -> {
                val intent = Intent(Settings.ACTION_LOCALE_SETTINGS)
                startActivity(intent)
            }

        }
    }

    override fun onCheckedChanged(cb: CompoundButton?, bool: Boolean) {
        if (bool) {
            reminderReceiver.setRepeatingReminder(this)
        } else {
            reminderReceiver.cancelReminder(this)
        }
    }
}